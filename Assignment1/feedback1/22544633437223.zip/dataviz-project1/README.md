# 02806 Data Viz: assignment 1

**To view assignment:**

1. Navigate to project root
2. Run a Python 3 HTTP server, i.e. `python3 -m http.server <port no.>`.

JavaScript dependencies for parts 3 and 4 are included as `/farmer.js` and `/src/app.js` respectively.